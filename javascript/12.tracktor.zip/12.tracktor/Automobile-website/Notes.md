-----------------
first section: 
-----------------

-> logo

-> fixed navigation bar: with logo and 3 sections links

-> one main hero section which takes 100vh size

-> Also add smooth scrolling effect
    w3 schools : https://www.w3schools.com/howto/howto_css_smooth_scroll.asp#section2
    video : https://www.youtube.com/watch?v=y9nlfqT4s9s

-> 3 sections : header section, Items sections, location section,Contact section,    

--------------------
second section:
--------------------

Items: